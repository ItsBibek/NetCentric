﻿//SET -A


//PROGRAM1

//using System;

//class Employee
//{
//    // Properties
//    public string Name { get; set; }
//    public int ID { get; set; }
//    public double Salary { get; set; }

//    // Constructor
//    public Employee(string name, int id, double salary)
//    {
//        Name = name;
//        ID = id;
//        Salary = salary;
//    }

//    public void DisplayInfo()
//    {
//        Console.WriteLine($"Name: {Name}, ID: {ID}, Salary: {Salary}");
//    }
//}

//class Program
//{
//    static void Main()
//    {
//        Employee emp = new Employee("Ram", 101, 50000);
//        emp.DisplayInfo();
//    }
//}



//PROGRAM2

//using System;

//class Shape
//{
//    public virtual void Draw()
//    {
//        Console.WriteLine("Drawing a shape.");
//    }
//}

//class Circle : Shape
//{
//    public override void Draw()
//    {
//        Console.WriteLine("Drawing a circle.");
//    }
//}

//class Program
//{
//    static void Main()
//    {
//        Shape s1 = new Shape();
//        s1.Draw();

//        Shape s2 = new Circle();
//        s2.Draw();
//    }
//}



//program3 is mvc Set as startup project and run


//PROGRAM 4 adon.net
// download System.Data.SqlClient nuget package

using System;
using System.Data.SqlClient;

class Program
{
    static void Main()
    {
        string connectionString = "Server=(localdb)\\MSSQLLocalDB;Database=setA;Trusted_Connection=True;";
        string query = "SELECT ID, Name, Salary FROM Employees";

        Console.WriteLine("Trying to connect...");

        try
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                Console.WriteLine("Connection successful!");

                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                bool hasRows = false;

                while (reader.Read())
                {
                    hasRows = true;
                    Console.WriteLine($"ID: {reader["ID"]}, Name: {reader["Name"]}, Salary: {reader["Salary"]}");
                }

                if (!hasRows)
                {
                    Console.WriteLine("No data found in Employees table.");
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("ERROR: " + ex.Message);
        }

        Console.WriteLine("Done.");
        Console.ReadLine(); // Keeps window open
    }
}
