﻿using Microsoft.AspNetCore.Mvc;
using GreetingAppMVC.Models;

namespace GreetingAppMVC.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(Person person)
        {
            ViewBag.Message = $"Hello, {person.Name} 👋";
            return View(person);
        }
    }
}
