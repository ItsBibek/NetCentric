﻿namespace GreetingAppMVC.Models
{
    public class Person
    {
        public string Name { get; set; }
    }
}
